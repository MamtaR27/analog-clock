setInterval(() => {


    date = new Date() ;
    htime = date.getHours() ;
    mtime = date.getMinutes() ;
    stime = date.getSeconds() ;
    hRoation = 30*htime + mtime/2 ;
    mRotation = 6*mtime ;
    sRoation = 6*stime ;
    

   hour.style.transform = `rotate(${hRoation}deg)` ;
   min.style.transform = `rotate(${mRotation}deg)` ;
   sec.style.transform = `rotate(${sRoation}deg)` ;

}, 1000);